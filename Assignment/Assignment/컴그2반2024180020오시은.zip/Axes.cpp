#include "Axes.h"

// ��ǥ�� ���� ���� ���� ����
GLuint VAO_axes = 0;
GLuint VBO_axes[2] = { 0, };

void InitAxesBuffer() {
	const float L = 30.0f;

	// [x,y,z] * 6�� ���� (GL_LINES�̹Ƿ� 2�� = 1�� ����)
	const float axes_vertices[] = {
		// X axis (red)
		-L, 0.0f, 0.0f,   
		 L, 0.0f, 0.0f,   

		 // Y axis (green)
		  0.0f, -L, 0.0f, 
		  0.0f,  L, 0.0f, 

		  // Z axis (blue)
		   0.0f, 0.0f, -L,
		   0.0f, 0.0f,  L,
	};

	const float axes_colors[] = {
		// X axis (red)
		1.0f, 0.0f, 0.0f, // start point
		1.0f, 0.0f, 0.0f, // end point

		// Y axis (green)
		0.0f, 1.0f, 0.0f, // start point
		0.0f, 1.0f, 0.0f, // end point

		// Z axis (blue)
		0.0f, 0.0f, 1.0f, // start point
		0.0f, 0.0f, 1.0f, // end point
	};

	glGenVertexArrays(1, &VAO_axes);
	glBindVertexArray(VAO_axes);

	glGenBuffers(2, VBO_axes);

	// positions -> location=0
	glBindBuffer(GL_ARRAY_BUFFER, VBO_axes[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(axes_vertices), axes_vertices, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

	// colors -> location=1
	glBindBuffer(GL_ARRAY_BUFFER, VBO_axes[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(axes_colors), axes_colors, GL_STATIC_DRAW);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void DrawAxes(const glm::mat4& view, const glm::mat4& projection, GLint mvpLocation)
{
	glBindVertexArray(VAO_axes);
	
	// ��ǥ���� ��ȯ ���� (���� ����)
	glm::mat4 model = glm::mat4(1.0f);
	glm::mat4 mvp = projection * view * model;
	
	glUniformMatrix4fv(mvpLocation, 1, GL_FALSE, glm::value_ptr(mvp));
	
	glLineWidth(2.0f);
	glDrawArrays(GL_LINES, 0, 6); // 6���� ���� = 3���� ����
	glBindVertexArray(0);
}